export declare function handler(event: any): Promise<void>;
