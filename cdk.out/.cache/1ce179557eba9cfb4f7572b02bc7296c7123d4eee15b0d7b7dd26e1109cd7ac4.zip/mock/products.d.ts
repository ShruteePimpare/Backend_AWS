export declare const products: {
    id: string;
    title: string;
    price: number;
    description: string;
}[];
