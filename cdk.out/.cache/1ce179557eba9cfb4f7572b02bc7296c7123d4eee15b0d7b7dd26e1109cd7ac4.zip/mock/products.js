"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.products = void 0;
exports.products = [
    { id: '1', title: 'Laptop', price: 999, description: 'A powerful laptop' },
    { id: '2', title: 'Phone', price: 499, description: 'A sleek smartphone' },
    { id: '3', title: 'Tablet', price: 299, description: 'A lightweight tablet' },
];
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvZHVjdHMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJwcm9kdWN0cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBYSxRQUFBLFFBQVEsR0FBRztJQUNwQixFQUFFLEVBQUUsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLFdBQVcsRUFBRSxtQkFBbUIsRUFBRTtJQUMxRSxFQUFFLEVBQUUsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLFdBQVcsRUFBRSxvQkFBb0IsRUFBRTtJQUMxRSxFQUFFLEVBQUUsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLFdBQVcsRUFBRSxzQkFBc0IsRUFBRTtDQUM5RSxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IHByb2R1Y3RzID0gW1xuICAgIHsgaWQ6ICcxJywgdGl0bGU6ICdMYXB0b3AnLCBwcmljZTogOTk5LCBkZXNjcmlwdGlvbjogJ0EgcG93ZXJmdWwgbGFwdG9wJyB9LFxuICAgIHsgaWQ6ICcyJywgdGl0bGU6ICdQaG9uZScsIHByaWNlOiA0OTksIGRlc2NyaXB0aW9uOiAnQSBzbGVlayBzbWFydHBob25lJyB9LFxuICAgIHsgaWQ6ICczJywgdGl0bGU6ICdUYWJsZXQnLCBwcmljZTogMjk5LCBkZXNjcmlwdGlvbjogJ0EgbGlnaHR3ZWlnaHQgdGFibGV0JyB9LFxuICBdO1xuICAiXX0=