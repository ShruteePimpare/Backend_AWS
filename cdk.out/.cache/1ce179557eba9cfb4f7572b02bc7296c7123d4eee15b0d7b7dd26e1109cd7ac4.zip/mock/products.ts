export const products = [
    { id: '1', title: 'Laptop', price: 999, description: 'A powerful laptop' },
    { id: '2', title: 'Phone', price: 499, description: 'A sleek smartphone' },
    { id: '3', title: 'Tablet', price: 299, description: 'A lightweight tablet' },
  ];
  